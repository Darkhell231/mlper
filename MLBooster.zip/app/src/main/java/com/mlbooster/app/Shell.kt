package com.mlbooster.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object Shell {
    fun available(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    /** Выполняет команду с правами shell через Shizuku. Пустая строка при ошибке. */
    fun run(cmd: String): String {
        if (!available()) return ""
        return try {
            // В Shizuku 13.x newProcess приватный, поэтому через reflection
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.trim()
        } catch (e: Throwable) {
            ""
        }
    }
}
