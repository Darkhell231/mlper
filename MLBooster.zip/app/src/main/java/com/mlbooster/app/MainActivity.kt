package com.mlbooster.app

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 80, 40, 40)
        }
        status = TextView(this).apply { textSize = 15f; setPadding(0, 0, 0, 30) }
        root.addView(status)

        fun btn(t: String, a: () -> Unit) {
            root.addView(Button(this).apply { text = t; setOnClickListener { a(); refresh() } })
        }

        fun chk(t: String, key: String, def: Boolean) {
            root.addView(CheckBox(this).apply {
                text = t
                isChecked = prefs.getBoolean(key, def)
                setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply() }
            })
        }

        btn("1. Разрешить Shizuku") { requestShizuku() }
        btn("2. Доступ к статистике использования") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        btn("3. Разрешить показ поверх других окон") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        btn("4. Разрешить уведомления") {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
            }
        }

        chk("Game Mode: производительность", "gamemode", true)
        chk("Не беспокоить на время игры", "dnd", true)
        chk("Принудительно 120 Гц (если экран поддерживает)", "refresh", false)

        btn("Запустить сервис") {
            startForegroundService(Intent(this, BoosterService::class.java))
        }
        btn("Остановить сервис") {
            stopService(Intent(this, BoosterService::class.java))
        }
        btn("Скомпилировать игру (speed)") { compileGame() }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        status.postDelayed({
            val shizukuRunning = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
            val shizukuOk = Shell.available()
            val usage = hasUsageAccess()
            val overlay = Settings.canDrawOverlays(this)
            val svc = BoosterService.running
            status.text = buildString {
                appendLine("Shizuku запущен: ${mark(shizukuRunning)}")
                appendLine("Shizuku разрешён: ${mark(shizukuOk)}")
                appendLine("Статистика использования: ${mark(usage)}")
                appendLine("Оверлей: ${mark(overlay)}")
                append("Сервис: ${mark(svc)}")
            }
        }, 400)
    }

    private fun mark(b: Boolean) = if (b) "✅" else "❌"

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(AppOpsManager::class.java)
        val mode = ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                toast("Shizuku не запущен. Запусти его через беспроводную отладку.")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                toast("Разрешение уже выдано")
            } else {
                Shizuku.requestPermission(100)
            }
        } catch (e: Throwable) {
            toast("Shizuku недоступен: установи и запусти приложение Shizuku")
        }
    }

    private fun compileGame() {
        if (!Shell.available()) {
            toast("Сначала разреши Shizuku")
            return
        }
        Thread {
            val found = Config.GAMES.filter {
                try { packageManager.getPackageInfo(it, 0); true } catch (e: Exception) { false }
            }
            if (found.isEmpty()) {
                toast("Mobile Legends не найден")
                return@Thread
            }
            toast("Компиляция запущена, это может занять минуту")
            found.forEach { Shell.run("cmd package compile -m speed -f $it") }
            toast("Компиляция завершена")
        }.start()
    }

    private fun toast(t: String) {
        runOnUiThread { Toast.makeText(this, t, Toast.LENGTH_LONG).show() }
    }
}
