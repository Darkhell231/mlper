package com.mlbooster.app

object Config {
    val GAMES = setOf(
        "com.mobile.legends",
        "com.mobilelegends.mi",
        "com.mobiin.gp",
        "com.mobilelegends.hwag"
    )
}
