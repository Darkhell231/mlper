# ML Booster

Утилита для Mobile Legends: при запуске игры включает Game Mode «performance»,
режим «Не беспокоить» (и по желанию 120 Гц), показывает оверлей с пингом,
температурой батареи и thermal-статусом, а после выхода из игры откатывает настройки.
Игру и её файлы приложение не трогает.

## Сборка на GitHub
1. Создай репозиторий, залей туда содержимое этой папки (в корне должны лежать `app/`, `.github/`, `build.gradle.kts`).
2. Вкладка **Actions** → Build APK (запустится сам после push или через Run workflow).
3. Скачай артефакт `MLBooster-debug`, внутри `app-debug.apk`.

## Установка и настройка
1. Установи **Shizuku** и запусти его через «Беспроводную отладку».
2. Установи `app-debug.apk`, открой приложение.
3. Нажми кнопки 1–4 по порядку. Вместо кнопок 2 и 3 можно выдать права через adb:
```
adb shell appops set com.mlbooster.app GET_USAGE_STATS allow
adb shell appops set com.mlbooster.app SYSTEM_ALERT_WINDOW allow
```
4. Нажми «Запустить сервис» и открой игру.

Android 12+ (minSdk 31). Для Xiaomi/Huawei и др. отключи ограничение батареи для приложения.
