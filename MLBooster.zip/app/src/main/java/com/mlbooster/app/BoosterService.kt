package com.mlbooster.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class BoosterService : Service() {

    companion object {
        @Volatile var running = false
    }

    private val exec = Executors.newSingleThreadScheduledExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    private var overlay: TextView? = null
    private var currentPkg: String? = null
    private var lastQuery = 0L
    private var gamePkg: String? = null

    private var dndChanged = false
    private var prevMin = ""
    private var prevPeak = ""
    private var refreshChanged = false

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("boost", "ML Booster", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "boost")
            .setContentTitle("ML Booster работает")
            .setContentText("Жду запуска Mobile Legends")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)

        exec.scheduleWithFixedDelay({
            try { tick() } catch (_: Throwable) {}
        }, 0, 2, TimeUnit.SECONDS)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        exec.shutdownNow()
        val g = gamePkg
        if (g != null) {
            // exec уже остановлен, откатываем в отдельном потоке
            Thread { restore(g) }.start()
            gamePkg = null
        }
        hideOverlay()
        super.onDestroy()
    }

    // ---------- основной цикл ----------

    private fun tick() {
        val fg = foregroundPackage()
        val game = fg?.takeIf { it in Config.GAMES }

        if (game != null && gamePkg == null) {
            gamePkg = game
            boost(game)
            showOverlay()
        } else if (game == null && gamePkg != null) {
            restore(gamePkg!!)
            gamePkg = null
            hideOverlay()
        }

        if (gamePkg != null) updateOverlay()
    }

    private fun foregroundPackage(): String? {
        val usm = getSystemService(UsageStatsManager::class.java)
        val now = System.currentTimeMillis()
        val from = if (lastQuery == 0L) now - 60 * 60 * 1000 else lastQuery - 1000
        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> currentPkg = e.packageName
                UsageEvents.Event.ACTIVITY_PAUSED ->
                    if (currentPkg == e.packageName) currentPkg = null
            }
        }
        lastQuery = now
        return currentPkg
    }

    // ---------- буст / откат ----------

    private fun boost(pkg: String) {
        if (prefs.getBoolean("gamemode", true)) {
            Shell.run("cmd game mode performance $pkg")
        }
        if (prefs.getBoolean("dnd", true)) {
            val zen = Shell.run("settings get global zen_mode")
            if (zen == "0" || zen.isEmpty()) {
                Shell.run("cmd notification set_dnd priority")
                dndChanged = true
            }
        }
        if (prefs.getBoolean("refresh", false)) {
            prevMin = Shell.run("settings get system min_refresh_rate")
            prevPeak = Shell.run("settings get system peak_refresh_rate")
            Shell.run("settings put system peak_refresh_rate 120")
            Shell.run("settings put system min_refresh_rate 120")
            refreshChanged = true
        }
    }

    private fun restore(pkg: String) {
        if (prefs.getBoolean("gamemode", true)) {
            Shell.run("cmd game mode standard $pkg")
        }
        if (dndChanged) {
            Shell.run("cmd notification set_dnd off")
            dndChanged = false
        }
        if (refreshChanged) {
            restoreSetting("min_refresh_rate", prevMin)
            restoreSetting("peak_refresh_rate", prevPeak)
            refreshChanged = false
        }
    }

    private fun restoreSetting(key: String, prev: String) {
        if (prev.isEmpty() || prev == "null") Shell.run("settings delete system $key")
        else Shell.run("settings put system $key $prev")
    }

    // ---------- оверлей ----------

    private fun showOverlay() {
        main.post {
            if (overlay != null || !Settings.canDrawOverlays(this)) return@post
            val tv = TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 11f
                setBackgroundColor(0x99000000.toInt())
                setPadding(16, 8, 16, 8)
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 20
                y = 60
            }
            getSystemService(WindowManager::class.java).addView(tv, lp)
            overlay = tv
        }
    }

    private fun hideOverlay() {
        main.post {
            overlay?.let {
                try { getSystemService(WindowManager::class.java).removeView(it) } catch (_: Throwable) {}
            }
            overlay = null
        }
    }

    private fun updateOverlay() {
        val ping = measurePing()
        val temp = batteryTemp()
        val thermal = thermalName()
        val text = "Ping: $ping\nБатарея: $temp\nThermal: $thermal"
        main.post { overlay?.text = text }
    }

    private fun measurePing(): String {
        return try {
            val t0 = System.nanoTime()
            Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
            "${(System.nanoTime() - t0) / 1_000_000} мс"
        } catch (_: Throwable) {
            "нет связи"
        }
    }

    private fun batteryTemp(): String {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        return "%.1f°C".format(t / 10f)
    }

    private fun thermalName(): String {
        val pm = getSystemService(PowerManager::class.java)
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "OK"
            PowerManager.THERMAL_STATUS_LIGHT -> "лёгкий"
            PowerManager.THERMAL_STATUS_MODERATE -> "средний"
            PowerManager.THERMAL_STATUS_SEVERE -> "сильный"
            PowerManager.THERMAL_STATUS_CRITICAL -> "критический"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "аварийный"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "выключение"
            else -> "?"
        }
    }
}
